package com.cts.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.cts.bean.Vehicle;

public class VehicleDAO {

	private static Connection con = null;
	private ResultSet rs = null;
	private Statement st = null;
	private PreparedStatement ps = null;
	int viewStatus = 0;

	public ArrayList<Vehicle> read(String val, String branch, String type, String Month) throws Exception {
		Vehicle v = new Vehicle(branch, type, val);

		ArrayList<Vehicle> VehicleList = new ArrayList<Vehicle>();
		int data_found = 0;
		try {
			String sql = null;
			VehicleDAO.connect();
			if (val.equals("service"))
				sql = "select * from vehicle where Branch =? and Vehicle_Type=? and month(Service_Due_Date)=?";
			else
				sql = "select * from vehicle where Branch =? and  Vehicle_Type=? and month(Insurance_Expiry_Date)=?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, branch);
			ps.setString(2, type);
			ps.setString(3, Month);

			System.out.println("Given query : " + ps.toString());
			rs = ps.executeQuery();

			while (rs.next()) {
				data_found = 1;
				Vehicle v1 = new Vehicle();
				v1.setVehicleNumber(rs.getString(1));
				v1.setBranch(rs.getString(2));
				v1.setVehicleType(rs.getString(3));
				v1.setInsuranceType(rs.getString(4));
				v1.setInsuranceExpiryDate(rs.getDate(5).toString());
				v1.setLastServiceDate(rs.getDate(6).toString());
				v1.setServiceDueDate(rs.getDate(7).toString());
				VehicleList.add(v1);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		if (data_found == 0)
			VehicleList = null;

		return VehicleList;
	}
	public ArrayList<Vehicle> expiryDays() throws Exception {
		ArrayList<Vehicle> v = new ArrayList<Vehicle>();
		try {
			VehicleDAO.connect();
			st = con.createStatement();

			Date dt = new Date();
			LocalDate ld = LocalDate.now();

			LocalDate ld1 = ld.plusDays(15);
			
			LocalDate ld_month = ld.plusMonths(15);

			String today_date = ld.toString();
			String date_afer_15days = ld1.toString();

			String sql = "select * from vehicle where Insurance_Expiry_Date >= '" + today_date
					+ "' AND Insurance_Expiry_Date <= '" + date_afer_15days + "' or Service_Due_Date <"+ ld_month.toString();
			rs = st.executeQuery(sql);
			while (rs.next()) {
				Vehicle ve = new Vehicle();
				ve.setVehicleNumber(rs.getString(1));
				ve.setBranch(rs.getString(2));
				ve.setVehicleType(rs.getString(3));
				ve.setInsuranceType(rs.getString(4));
				ve.setInsuranceExpiryDate(rs.getString(5));
				ve.setLastServiceDate(rs.getString(6));
				ve.setServiceDueDate(rs.getString(7));
				v.add(ve);

			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (con != null)
				con.close();
		}
		return v;

	}


	public int insert(Vehicle v) throws Exception {
		int insertStatus = 0;
		try {
			connect();
			ps = con.prepareStatement("insert into vehicle values (?,?,?,?,?,?,?)");
			ps.setString(1, v.getVehicleNumber());
			ps.setString(2, v.getBranch());
			ps.setString(3, v.getVehicleType());
			ps.setString(4, v.getInsuranceType());
			ps.setString(5, v.getInsuranceExpiryDate());
			ps.setString(6, v.getLastServiceDate());
			ps.setString(7, v.getServiceDueDate());
			insertStatus = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (con != null) {
				con.close();
			}
		}
		return insertStatus;
	}

	public List<Vehicle> readAll() throws Exception {
		List<Vehicle> vehicle = new ArrayList<Vehicle>();
		try {
			connect();
			st = con.createStatement();
			rs = st.executeQuery("Select * from vehicle");
			while (rs.next()) {
				Vehicle v = new Vehicle();
				v.setVehicleNumber(rs.getString(1));
				v.setBranch(rs.getString(2));
				v.setVehicleType(rs.getString(3));
				v.setInsuranceType(rs.getString(4));
				v.setInsuranceExpiryDate(rs.getString(5));
				v.setLastServiceDate(rs.getString(6));
				v.setServiceDueDate(rs.getString(7));
				vehicle.add(v);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (con != null) {
				con.close();
			}
		}
		return vehicle;
	}

	public int update(Vehicle v) throws Exception {
		int updateStatus = 0;
		try {
			connect();
			ps = con.prepareStatement(
					"update vehicle set Branch=?,Vehicle_type=?,Insurance_Type=?,Insurance_Expiry_Date=?,Last_Service_Date=?,Service_Due_Date=? where Vehicle_Number=?");
			ps.setString(1, v.getBranch());
			ps.setString(2, v.getVehicleType());
			ps.setString(3, v.getInsuranceType());
			ps.setString(4, v.getInsuranceExpiryDate());
			ps.setString(5, v.getLastServiceDate());
			ps.setString(6, v.getServiceDueDate());
			ps.setString(7, v.getVehicleNumber());
			updateStatus = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (con != null) {
				con.close();
			}
		}
		return updateStatus;
	}

	public Vehicle read(String vno) throws Exception {
		Vehicle v = new Vehicle();
		try {
			connect();
			st = con.createStatement();
			rs = st.executeQuery("Select * from vehicle where Vehicle_Number='" + vno + "'");
			while (rs.next()) {
				v.setVehicleNumber(rs.getString(1));
				v.setBranch(rs.getString(2));
				v.setVehicleType(rs.getString(3));
				v.setInsuranceType(rs.getString(4));
				v.setInsuranceExpiryDate(rs.getString(5));
				v.setLastServiceDate(rs.getString(6));
				v.setServiceDueDate(rs.getString(7));
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (con != null) {
				con.close();
			}
		}
		return v;
	}

	public static Connection connect() throws Exception {
		Class.forName("com.mysql.jdbc.Driver");
		con = DriverManager.getConnection("jdbc:mysql://localhost:3306/vehicle_reservation_system", "root", "root");
		return con;
	}
}

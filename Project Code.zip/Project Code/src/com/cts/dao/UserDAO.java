package com.cts.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import com.cts.bean.User;
import com.cts.dao.UserDAO;

public class UserDAO {

	private static Connection con = null;
	private PreparedStatement ps = null;
	private ResultSet rs = null;
	private Statement st = null;

	public int validUser(String id, String password) {

		int count = 0;

		try {
			UserDAO.connect();
			String sql = "Select * from user where Employee_Id=? and password=?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, id);
			ps.setString(2, password);

			System.out.println(id + " " + password);

			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				count = 1;
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return count;
	}

	public int insert(User v) throws Exception {
		int insertStatus = 0;
		try {
			UserDAO.connect();
			ps = con.prepareStatement("insert into user values (?,?,?,?,?,?,?,?,?)");
			ps.setString(1, v.getEmployeeId());
			ps.setString(2, v.getFirstName());
			ps.setString(3, v.getLastName());
			ps.setInt(4, v.getAge());
			ps.setString(5, v.getGender());
			ps.setLong(6, v.getContactNumber());
			ps.setString(7, v.getEmailId());
			ps.setString(8, v.getPassword());
			ps.setString(9, v.getBranchId());

			insertStatus = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (con != null)
				con.close();
		}
		return insertStatus;
	}

	public static Connection connect() throws Exception {
		Class.forName("com.mysql.jdbc.Driver");
		con = DriverManager.getConnection("jdbc:mysql://localhost:3306/vehicle_reservation_system", "root", "root");
		return con;
	}

}

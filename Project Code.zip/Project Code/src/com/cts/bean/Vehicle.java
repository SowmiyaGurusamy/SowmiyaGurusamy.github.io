package com.cts.bean;

public class Vehicle {

	private String vehicleNumber;
	private String branch;
	private String vehicleType;
	private String insuranceType;
	private String insuranceExpiryDate;
	private String lastServiceDate;
	private String serviceDueDate;

	public Vehicle(){}
	
	public void Vehicle(String branch, String vehicleType, String insuranceExpiryDate) {

		this.branch = branch;
		this.vehicleType = vehicleType;
		this.insuranceExpiryDate = insuranceExpiryDate;
	}

	public Vehicle(String branch, String vehicleType, String serviceDueDate) {
		super();
		this.branch = branch;
		this.vehicleType = vehicleType;
		this.serviceDueDate = serviceDueDate;
	}

	public String getVehicleNumber() {
		return vehicleNumber;
	}

	public void setVehicleNumber(String vehicleNumber) {
		this.vehicleNumber = vehicleNumber;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public String getVehicleType() {
		return vehicleType;
	}

	public void setVehicleType(String vehicleType) {
		this.vehicleType = vehicleType;
	}

	public String getInsuranceType() {
		return insuranceType;
	}

	public void setInsuranceType(String insurance_Type) {
		this.insuranceType = insurance_Type;
	}

	public String getInsuranceExpiryDate() {
		return insuranceExpiryDate;
	}

	public void setInsuranceExpiryDate(String insuranceExpiryDate) {
		this.insuranceExpiryDate = insuranceExpiryDate;
	}

	public String getLastServiceDate() {
		return lastServiceDate;
	}

	public void setLastServiceDate(String lastServiceDate) {
		this.lastServiceDate = lastServiceDate;
	}

	public String getServiceDueDate() {
		return serviceDueDate;
	}

	public void setServiceDueDate(String serviceDueDate) {
		this.serviceDueDate = serviceDueDate;
	}

}

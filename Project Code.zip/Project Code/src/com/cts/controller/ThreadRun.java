package com.cts.controller;
import java.time.LocalTime;

public class ThreadRun extends Thread{
	
	public void run()
	{
		 
 			while (true)
 			{
		    LocalTime lt = LocalTime.now();
			int hours = lt.getHour();
			int min = lt.getMinute();
			int sec = lt.getSecond();			
			System.out.println("Sowmiya : " + hours + ":"+min + ":"+sec);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {				 
				e.printStackTrace();
			}
			
			if (hours == 0) 
			{
				if (min == 1 && sec == 0)
				{
					SendingMail sm = new SendingMail();
					try
					{						 
						sm.sendMail();
					}
					catch (Exception e)
					{
						System.out.println(e);
					}

				}
			}
 			}
	 
	}
	
	public static void main (String args[])  
	{
	}

}

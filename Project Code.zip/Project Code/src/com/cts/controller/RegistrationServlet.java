
package com.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cts.bean.User;
import com.cts.dao.UserDAO;
import com.cts.dao.VehicleDAO;

/**
 * Servlet implementation class InsertData
 */
@WebServlet("/RegistrationServlet")
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public RegistrationServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		// response.getWriter().append("Served at: ").append(request.getContextPath());
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		UserDAO userDAO = new UserDAO();
		System.out.println("In the servlet..");
		try {
			User v = new User();
			String employeeId = request.getParameter("employeeId");
			String firstName = request.getParameter("firstName");
			String lastName = request.getParameter("lastName");
			int age = Integer.parseInt(request.getParameter("age"));
			String gender = request.getParameter("gender");
			long contactNumber = Long.parseLong(request.getParameter("contactNumber"));
			String emailId = request.getParameter("emailId");
			String password = request.getParameter("password");
			String branchId = request.getParameter("branchId");

			v.setEmployeeId(employeeId);
			v.setFirstName(firstName);
			v.setLastName(lastName);
			v.setAge(age);
			v.setGender(gender);
			v.setContactNumber(contactNumber);
			v.setEmailId(emailId);
			v.setPassword(password);
			v.setBranchId(branchId);
			int insertStatus = 0;
			insertStatus = userDAO.insert(v);
			if (insertStatus != 0) {
				System.out.println("Data inserted successully..");
				request.setAttribute("Registration", "Registered");
				//response.sendRedirect("index.jsp");
		        RequestDispatcher rd=request.getRequestDispatcher("/index.jsp");  
		        rd.forward(request, response);  
			} else {
				System.out.println("Data not inserted ..");
				response.sendRedirect("registration.jsp");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
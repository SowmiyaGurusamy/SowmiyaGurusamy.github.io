package com.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cts.dao.VehicleDAO;
import com.cts.bean.Vehicle;

/**
 * Servlet implementation class UpdateDetail
 */
@WebServlet("/UpdateDetail")
public class UpdateDetail extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public UpdateDetail() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		// response.getWriter().append("Served at: ").append(request.getContextPath())
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		VehicleDAO vdao = new VehicleDAO();
		try {
			int updateStatus = 0;
			Vehicle v = new Vehicle();
			String vno = request.getParameter("vehicleNumber");
			String branch = request.getParameter("branch");
			String vtype = request.getParameter("vehicleType");
			String instype = request.getParameter("insuranceType");
			String insexpdate = request.getParameter("insuranceExpiryDate");
			String lastserdate = request.getParameter("lastServiceDate");
			String servicedate = request.getParameter("serviceDueDate");
			v.setVehicleNumber(vno);
			v.setBranch(branch);
			v.setVehicleType(vtype);
			v.setInsuranceType(instype);
			v.setInsuranceExpiryDate(insexpdate);
			v.setLastServiceDate(lastserdate);
			v.setServiceDueDate(servicedate);
			updateStatus = vdao.update(v);

			if (updateStatus != 0) {
				response.sendRedirect("ViewDetail");
			} else {
				out.print("Unable to Update...Data");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

package com.cts.controller;
import java.util.List;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import com.cts.bean.Vehicle;
import com.cts.dao.VehicleDAO;

public class SendingMail {
	public static void main(String[] args) throws Exception {}

	
	 public void sendMail() throws Exception {
	   // Recipient's email ID needs to be mentioned.
		String to = "helenabloom1197@gmail.com";

		// Sender's email ID needs to be mentioned
		String from = "helenabloom1197@gmail.com";
		final String username = "helenabloom1197@gmail.com";//change accordingly
		final String password = "sss@123456";//change accordingly

		// Assuming you are sending email through relay.jangosmtp.net
		String host = "mail.google.com";

		Properties props = new Properties();
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", host);
		props.put("mail.smtp.port", "25");

		// Get the Session object.
		Session session = Session.getInstance(props,
				new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(username, password);
			}
		});

		try {
			// Create a default MimeMessage object.
			Message message = new MimeMessage(session);

			// Set From: header field of the header.
			message.setFrom(new InternetAddress(from));

			// Set To: header field of the header.
			message.setRecipients(Message.RecipientType.TO,
					InternetAddress.parse(to));

			// Set Subject: header field
			message.setSubject("Testing Subject");

			VehicleDAO vehiclesDAO = new VehicleDAO();
			List<Vehicle> vehiclesList = null;
			String html_mesage = "<HTML><BODY><TABLE border='1' align='center'>";
		 
				vehiclesList =vehiclesDAO.expiryDays();


				html_mesage += "		<tr>\r\n" + 
						"			<th>Vehicle Number</th>\r\n" + 
						"			<th>Branch</th>\r\n" + 
						"			<th>Vehicle Type</th>\r\n" + 
						"			<th>Insurance Type</th>\r\n" + 
						"			<th>Insurance Expiry Date</th>\r\n" + 
						"			<th>Last Serviced Date</th>\r\n" + 
						"			<th>Service Due Date</th>\r\n" + 
						"		</tr>";
				for(Vehicle v : vehiclesList)
				{
					html_mesage += "<TR> <TD>" + v.getVehicleNumber() + "</TD> <td>" + v.getBranch() + "</TD> <td>" + v.getVehicleType() +"</TD> <td>" + v.getInsuranceType() + "</TD> <td>" + v.getInsuranceExpiryDate() +"</TD> <td>" + v.getLastServiceDate() + "</TD> <td>" + v.getServiceDueDate() + "</td></tr>";  
				}



				html_mesage = html_mesage + "</TABLE></BODY></HTML>";
				System.out.println(html_mesage);


				// Send the actual HTML message, as big as you like
				
				message.setContent(html_mesage, "text/html");

				// Send message
				Transport.send(message);

				System.out.println("Sent message successfully....");

			} catch (MessagingException e) {
				e.printStackTrace();
				throw new RuntimeException(e);
			}
		}

}